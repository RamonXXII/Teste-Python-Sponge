def getNextMultipleOfSeven(num):
    # find the next multiple of 7 strictly greater than num
    return num + (__ - num % __)
