print("hello world")
print(world) #distractor