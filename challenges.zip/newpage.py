print("Write your code here")
