# Canvas example

This allows a (currently limited) subset of basic draw commands to be sent to a standard HTML canvas context which is size 500 by 400.

The typ attribute in the JSON must be set to 'canvas'.




