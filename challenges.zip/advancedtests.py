# DEBUG THIS CODE BY ADDING OR CHANGING THREE SYMBOLS ONLY!

a = int(input("Enter a:"))
b = int(input("Enter b:")

print(f"One num was {a}")
print(f"One num was {b")
print(f"The sum is {a*b}")

