# Parsons problems

You can use #start and #end markers in Parsons problems to mark the code that is rearrangeable.

You are only allowed one #start and #end block per problem.

There must be a #start marker to use this setting but the #end marker is optional.

This example also demonstrates using the turtle within a Parsons problem.

**Rearrange this code to draw a square by repeating four times the instruction to 'first move forward and then turn left'.**