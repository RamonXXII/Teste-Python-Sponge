# Turtle example

Similarly, with the typ attribute also set to 'canvas', our turtle object facilitates most basic python turtle control instructions for pen, fill, colors and position control.

It does not implement all turtle functionality currently however including reading the state of the turtle.





