# LIBRARY IMPORTS
import turtle

# MAIN PROGRAM

n = int(input("enter length of side: "))

turtle.pencolor("red")

for count in range(__):
    turtle.forward(___)
    turtle.right(__)

turtle.done()
