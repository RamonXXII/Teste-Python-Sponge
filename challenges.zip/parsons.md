# Parsons problems

You can also set Parsons drag & drop problems with thanks to the js-parsons library which we build upon here.

To do this you simply write your correct code in the code editor and then add a typ attribute in the JSON with the value "parsons". 

Lave instructions in the guide about what the code should do when correctly arranged e.g. 

**Sequence the first four lines of the well known children's song**

When the challenge is viewed, the lines will be arranged randomly each time for correct drag & drop including adding indentation. The sequenced code can then also be run to interact with it.

To add distractors, you can add lines of code with the comment #distractor at the end of the line as shown.